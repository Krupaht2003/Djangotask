from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
#def one(request):
    #return HttpResponse("Krupa")

def devops(request):
    return render(request, 'devops.html')